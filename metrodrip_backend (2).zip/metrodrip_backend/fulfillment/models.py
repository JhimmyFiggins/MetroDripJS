from django.db import models


class ShippingShippingZone(models.Model):
    id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length=50, unique=True)
    fee = models.IntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = 'shipping_shippingzone'


class ShippingShipment(models.Model):
    id = models.BigAutoField(primary_key=True)
    order_ref = models.BigIntegerField(unique=True)
    courier = models.CharField(max_length=20)
    waybill_no = models.CharField(max_length=64)
    tracking_url = models.CharField(max_length=254, null=True, blank=True)
    status = models.CharField(max_length=20, default='pending')
    booked_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = 'shipping_shipment'


class NotificationsDeviceToken(models.Model):
    id = models.BigAutoField(primary_key=True)
    customer_ref = models.BigIntegerField()
    token = models.CharField(max_length=200)
    platform = models.CharField(max_length=10)
    created_at = models.DateTimeField(auto_now_add=True)
    last_seen_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'notifications_devicetoken'
        constraints = [
            models.UniqueConstraint(
                fields=['token', 'platform'],
                name='uniq_token_platform'
            ),
        ]


class NotificationsNotification(models.Model):
    id = models.BigAutoField(primary_key=True)
    customer_ref = models.BigIntegerField()
    title = models.CharField(max_length=140)
    body = models.TextField()
    category = models.CharField(max_length=10)
    order_ref = models.BigIntegerField(null=True, blank=True)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'notifications_notification'